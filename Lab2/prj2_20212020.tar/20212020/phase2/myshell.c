#include "csapp.h"
#include <errno.h>

#define MAXARGS 128

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv);
void execute_command(char **argv, int input_fd, int output_fd);

int main() 
{
    char cmdline[MAXLINE]; 

    while (1) {
        printf("CSE4100-SP-P2> ");              
        char* rst = fgets(cmdline, MAXLINE, stdin); 
        if (feof(stdin) || rst == NULL)
            exit(0);
    
        eval(cmdline);
    } 
}

void eval(char *cmdline) 
{
    char *argv[MAXARGS]; 
    char buf[MAXLINE];   
    char *cmd[MAXARGS];  
    int bg;              
    pid_t pid;           
    int i = 0;           

    strcpy(buf, cmdline);

    char *token = strtok(buf, "|");
    while (token != NULL && i < MAXARGS) {
        cmd[i++] = token;
        token = strtok(NULL, "|");
    }

    int input_fd = STDIN_FILENO; 
    int pipe_fds[2]; 
    for (int j = 0; j < i; j++) {
        char *cmdline = cmd[j];
        bg = parseline(cmdline, argv);
        if (argv[0] == NULL)  
            continue;   
        if (!builtin_command(argv)) {
            if (j < i - 1) {
                pipe(pipe_fds);
                execute_command(argv, input_fd, pipe_fds[1]);
                close(pipe_fds[1]);
                input_fd = pipe_fds[0];
            } 
            else
                execute_command(argv, input_fd, STDOUT_FILENO);
        }
    }
}

void execute_command(char **argv, int input_fd, int output_fd) {
    pid_t pid;
    pid = fork();
    if (pid == 0) {
        if (input_fd != STDIN_FILENO) {
            dup2(input_fd, STDIN_FILENO);
            close(input_fd); 
        }
        if (output_fd != STDOUT_FILENO) {
            dup2(output_fd, STDOUT_FILENO);
            close(output_fd);
        }
        if (execvp(argv[0], argv) < 0) {
            printf("%s: Command not found.\n", argv[0]);
            exit(0);
        }
    }
    int status;
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid error");
    }
}

int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit") || !strcmp(argv[0], "exit"))
        exit(0);  
    if (!strcmp(argv[0], "cd")) { 
        if (argv[1] == NULL || !strcmp(argv[1], "~")) {
            chdir(getenv("HOME"));
        } 
        else {
            if (chdir(argv[1]) < 0) {
                printf("bash: cd: %s: No such file or directory\n", argv[1]);
            }
        }
        return 1;
    }
    if (!strcmp(argv[0], "&"))   
        return 1;
    return 0;                   
}

int parseline(char *buf, char **argv) 
{
    char *delim;         
    int argc;            
    int bg;              

    buf[strlen(buf)-1] = ' '; 
    while (*buf && (*buf == ' '))
        buf++;

    argc = 0;

    while ((delim = strchr(buf, ' '))) {

        if (*buf == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        }
        else if (*buf == '"') {
            buf++;
            delim = strchr(buf, '"');
        }

        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;

        while (*buf && (*buf == ' ')) 
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  
        return 1;

    if ((bg = (*argv[argc-1] == '&')) != 0)
        argv[--argc] = NULL;

    return bg;
}