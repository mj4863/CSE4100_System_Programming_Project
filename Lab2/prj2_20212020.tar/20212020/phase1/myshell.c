#include "csapp.h"
#include <errno.h>

#define MAXARGS 128

void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 

int main() 
{
    char cmdline[MAXLINE];

    while (1) {
        printf("CSE4100-SP-P2> ");              
        char* rst = fgets(cmdline, MAXLINE, stdin); 
        if (feof(stdin) || rst == NULL)
            exit(0);
    
        eval(cmdline);
    } 
}

void eval(char *cmdline) 
{
    char *argv[MAXARGS]; 
    char buf[MAXLINE];   
    char *cmd[MAXARGS];  
    int bg;
    pid_t pid;         
    int i = 0;         

    strcpy(buf, cmdline);

    cmd[i] = strtok(buf, "&&");
    while (cmd[i] != NULL) {
        i++;
        cmd[i] = strtok(NULL, "&&");
    }

    for (int j = 0; j < i; j++) {
        bg = parseline(cmd[j], argv); 
        if (argv[0] == NULL)  
            continue;   
        if (!builtin_command(argv)) {
            pid = Fork();

            if (pid == 0) { 
                if (execvp(argv[0], argv) < 0) { 
                    printf("%s: Command not found.\n", argv[0]);
                    exit(0);
                }
            }
        
            if (!bg){ 
                int status;
                if (waitpid(pid, &status, 0) < 0) {
                    perror("waitpid error");
                }
            }
        }
    }
    return;
}

int builtin_command(char **argv) 
{
    if (!strcmp(argv[0], "quit") || !strcmp(argv[0], "exit")) 
        exit(0);  
    if (!strcmp(argv[0], "cd")) { 
        if (argv[1] == NULL || !strcmp(argv[1], "~")) {
            chdir(getenv("HOME"));
        } 
        else {
            if (chdir(argv[1]) < 0) {
                printf("bash: cd: %s: No such file or directory\n", argv[1]);
            }
        }
        return 1;
    }
    if (!strcmp(argv[0], "&"))  
        return 1;
    return 0;                     
}

int parseline(char *buf, char **argv) 
{
    char *delim;         
    int argc;            
    int bg;              

    buf[strlen(buf)-1] = ' '; 
    while (*buf && (*buf == ' '))
        buf++;

    argc = 0;

    while ((delim = strchr(buf, ' '))) {

        if (buf[0] == '\'') {
            buf++;
            delim = strchr(buf, '\'');
        }
        else if (buf[0] == '"') {
            buf++;
            delim = strchr(buf, '"');
        }

        argv[argc++] = buf;
        *delim = '\0';
        buf = delim + 1;

        while (*buf && (*buf == ' ')) 
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  
        return 1;

    if ((bg = (*argv[argc-1] == '&')) != 0)
        argv[--argc] = NULL;

    return bg;
}