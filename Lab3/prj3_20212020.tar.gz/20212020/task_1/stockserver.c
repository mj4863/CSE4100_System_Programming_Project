
#include "csapp.h"

typedef struct {                    /* Represents a pool of connected descriptors */ //line:conc:echoservers:beginpool
    int maxfd;                      /* Largest descriptor in read_set */   
    fd_set read_set;                /* Set of all active descriptors */
    fd_set ready_set;               /* Subset of descriptors ready for reading  */
    int nready;                     /* Number of ready descriptors from select */   
    int maxi;                       /* Highwater index into client array */
    int clientfd[FD_SETSIZE];       /* Set of active descriptors */
    rio_t clientrio[FD_SETSIZE];    /* Set of active read buffers */
} pool; //line:conc:echoservers:endpool

typedef struct item {
    int ID;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex;
} item;

typedef struct TreeNode {
    item stock;
    struct TreeNode *left;
    struct TreeNode *right;
} TreeNode;

TreeNode *root = NULL;

void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p, struct sockaddr_storage *clientaddr);
void check_clients(pool *p);
void load_stock_data(const char *filename);
void save_stock_data(const char *filename);
void save_stock_data_recursive(FILE *fp, TreeNode *node);
TreeNode* insert_stock(TreeNode *node, item stock);
TreeNode* find_stock(TreeNode *node, int ID);
void show_stock(int connfd, char *output);
void buy_stock(int connfd, int ID, int count, char *output);
void sell_stock(int connfd, int ID, int count, char *output);
void show_stock_recursive(TreeNode *node, char *buf);
void sigint_handler(int sig) {
    save_stock_data("stock.txt");
    exit(0);
}

int main(int argc, char **argv) {
    signal(SIGINT, sigint_handler);
    signal(SIGTERM, sigint_handler);
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    static pool pool; 

    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool); //line:conc:echoservers:initpool

    load_stock_data("stock.txt");

    while (1) {
		/* Wait for listening/connected descriptor(s) to become ready */
		pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL, NULL, NULL);

		/* If listening descriptor ready, add new client to pool */
		if (FD_ISSET(listenfd, &pool.ready_set)) { //line:conc:echoservers:listenfdready
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); //line:conc:echoservers:accept
			add_client(connfd, &pool, &clientaddr); //line:conc:echoservers:addclient
		}
		/* Echo a text line from each ready connected descriptor */ 
		check_clients(&pool); //line:conc:echoservers:checkclients
    }
    save_stock_data("stock.txt");
}

/* $begin init_pool */
void init_pool(int listenfd, pool *p) 
{
    /* Initially, there are no connected descriptors */
    int i;
    p->maxi = -1;                   //line:conc:echoservers:beginempty
    for (i=0; i< FD_SETSIZE; i++)  
		p->clientfd[i] = -1;        //line:conc:echoservers:endempty

    /* Initially, listenfd is only member of select read set */
    p->maxfd = listenfd;            //line:conc:echoservers:begininit
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set); //line:conc:echoservers:endinit
}
/* $end init_pool */

/* $begin add_client */
void add_client(int connfd, pool *p, struct sockaddr_storage *clientaddr)
{
    int i;
    p->nready--;

    char client_hostname[MAXLINE], client_port[MAXLINE];
    getnameinfo((struct sockaddr *)clientaddr, sizeof(struct sockaddr_storage), 
                    client_hostname, MAXLINE, client_port, MAXLINE, 0);
    printf("Connected to (%s, %s)\n", client_hostname, client_port);

    for (i = 0; i < FD_SETSIZE; i++)  /* Find an available slot */
		if (p->clientfd[i] < 0) { 
			/* Add connected descriptor to the pool */
			p->clientfd[i] = connfd;                 //line:conc:echoservers:beginaddclient
			Rio_readinitb(&p->clientrio[i], connfd); //line:conc:echoservers:endaddclient

			/* Add the descriptor to descriptor set */
			FD_SET(connfd, &p->read_set); //line:conc:echoservers:addconnfd

			/* Update max descriptor and pool highwater mark */
			if (connfd > p->maxfd) //line:conc:echoservers:beginmaxfd
				p->maxfd = connfd; //line:conc:echoservers:endmaxfd
			if (i > p->maxi)       //line:conc:echoservers:beginmaxi
				p->maxi = i;       //line:conc:echoservers:endmaxi
			break;
		}
		if (i == FD_SETSIZE) /* Couldn't find an empty slot */
			app_error("add_client error: Too many clients");
}
/* $end add_client */

/* $begin check_clients */
void check_clients(pool *p) 
{
    int i, connfd, n;
    char buf[MAXLINE]; 
    rio_t rio;
    char command[MAXLINE], id_str[MAXLINE], count_str[MAXLINE];
    int id, count;
    char output[MAXLINE]; // 결과를 저장할 큰 버퍼

    for (i = 0; (i <= p->maxi) && (p->nready > 0); i++) {
        connfd = p->clientfd[i];
        rio = p->clientrio[i];

        if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) { 
            p->nready--;
            if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
                printf("server received %d bytes\n", n);

                sscanf(buf, "%s %s %s", command, id_str, count_str);
                output[0] = '\0';
                strcat(output, buf);
                
                if (strcmp(command, "exit") == 0) {
                    Close(connfd);
                    FD_CLR(connfd, &p->read_set);
                    p->clientfd[i] = -1;
                    return;
                }
                else if (strcmp(command, "show") == 0) {
                    show_stock(connfd, output);
                } 
                else if (strcmp(command, "buy") == 0) {
                    id = atoi(id_str);
                    count = atoi(count_str);
                    buy_stock(connfd, id, count, output);
                } 
                else if (strcmp(command, "sell") == 0) {
                    id = atoi(id_str);
                    count = atoi(count_str);
                    sell_stock(connfd, id, count, output);
                } 
                else {
                    strcat(output, "Invalid command\n");
                }
                Rio_writen(connfd, output, MAXLINE); // 결과를 한 번에 전송
            }
            else { 
                Close(connfd);
                FD_CLR(connfd, &p->read_set);
                p->clientfd[i] = -1;
            }
        }
    }
}
/* $end check_clients */

void load_stock_data(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        app_error("Could not open stock file");
    }
    item stock;
    while (fscanf(fp, "%d %d %d", &stock.ID, &stock.left_stock, &stock.price) != EOF) {
        stock.readcnt = 0;
        Sem_init(&stock.mutex, 0, 1);
        root = insert_stock(root, stock);
    }
    fclose(fp);
}

void save_stock_data(const char *filename) {
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        app_error("Could not open stock file");
    }
    save_stock_data_recursive(fp, root);
    fclose(fp);
}

void save_stock_data_recursive(FILE *fp, TreeNode *node) {
    if (node) {
        fprintf(fp, "%d %d %d\n", node->stock.ID, node->stock.left_stock, node->stock.price);
        save_stock_data_recursive(fp, node->left);
        save_stock_data_recursive(fp, node->right);
    }
}

TreeNode* insert_stock(TreeNode *node, item stock) {
    if (node == NULL) {
        node = (TreeNode*)malloc(sizeof(TreeNode));
        node->stock = stock;
        node->left = node->right = NULL;
    } 
    else if (stock.ID < node->stock.ID)
        node->left = insert_stock(node->left, stock);
    else
        node->right = insert_stock(node->right, stock);
    return node;
}

TreeNode* find_stock(TreeNode *node, int ID) {
    if (node == NULL || node->stock.ID == ID)
        return node;

    if (ID < node->stock.ID)
        return find_stock(node->left, ID);
    else
        return find_stock(node->right, ID);
}

void show_stock(int connfd, char *output) {
    char buf[MAXLINE] = {0}; 
    show_stock_recursive(root, buf);
    strcat(output, buf);  
}

void show_stock_recursive(TreeNode *node, char *buf) {
    char temp[MAXLINE];
    if (node != NULL) {
        show_stock_recursive(node->left, buf);
        sprintf(temp, "%d %d %d\n", node->stock.ID, node->stock.left_stock, node->stock.price);
        strcat(buf, temp);
        show_stock_recursive(node->right, buf);
    }
}

void buy_stock(int connfd, int ID, int count, char *output) {
    TreeNode *stock_node = find_stock(root, ID);
    char buf[MAXLINE];

    if (stock_node == NULL) {
        sprintf(buf, "Stock with ID %d not found.\n", ID);
        strcat(output, buf);
        return;
    }

    P(&stock_node->stock.mutex);
    if (stock_node->stock.left_stock < count) {
        sprintf(buf, "Not enough left stocks\n");
    } 
    else {
        stock_node->stock.left_stock -= count;
        sprintf(buf, "[buy] success\n");
    }
    V(&stock_node->stock.mutex);

    strcat(output, buf);
}

void sell_stock(int connfd, int ID, int count, char *output) {
    TreeNode *stock_node = find_stock(root, ID);
    char buf[MAXLINE];

    if (stock_node == NULL) {
        sprintf(buf, "Stock with ID %d not found.\n", ID);
        strcat(output, buf);
        return;
    }

    P(&stock_node->stock.mutex);
    stock_node->stock.left_stock += count;
    sprintf(buf, "[sell] success\n");
    V(&stock_node->stock.mutex);

    strcat(output, buf);
}