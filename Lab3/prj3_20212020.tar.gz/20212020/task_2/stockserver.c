#include "csapp.h"
#define NTHREADS 1024
#define SBUFSIZE 64

typedef struct item {
    int id;
    int left_stock;
    int price;
    int readcnt;
    sem_t mutex;
    sem_t w;
    struct item *left;
    struct item *right;
} item;

typedef struct {
    item *root;
    sem_t mutex;
} stock_tree_t;

typedef struct {
    int *buf;          /* Buffer array */         
    int n;             /* Maximum number of slots */
    int front;         /* buf[(front+1)%n] is first item */
    int rear;          /* buf[rear%n] is last item */
    sem_t mutex;       /* Protects accesses to buf */
    sem_t slots;       /* Counts available slots */
    sem_t items;       /* Counts available items */
} sbuf_t;

sbuf_t sbuf; /* Shared buffer of connected descriptors */
stock_tree_t stock_tree;

void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, int item);
int sbuf_remove(sbuf_t *sp);
void *thread(void *vargp);
void handle_client(int connfd);
void sigint_handler(int signo);
void stock_tree_init(stock_tree_t *tree);
item* insert_item(item *node, int id, int left_stock, int price);
item* find_item(item *node, int id);
void load_items(stock_tree_t *tree, const char *filename);
void save_items(item *node, FILE *fp);
void preorder(item *node, char *buf);

void sbuf_init(sbuf_t *sp, int n) {
    sp->buf = Calloc(n, sizeof(int)); 
    sp->n = n;                       /* Buffer holds max of n items */
    sp->front = sp->rear = 0;        /* Empty buffer iff front == rear */
    Sem_init(&sp->mutex, 0, 1);      /* Binary semaphore for locking */
    Sem_init(&sp->slots, 0, n);      /* Initially, buf has n empty slots */
    Sem_init(&sp->items, 0, 0);      /* Initially, buf has zero data items */
}

void sbuf_deinit(sbuf_t *sp) {
    Free(sp->buf);
}

void sbuf_insert(sbuf_t *sp, int item) {
    P(&sp->slots);                          /* Wait for available slot */
    P(&sp->mutex);                          /* Lock the buffer */
    sp->buf[(++sp->rear)%(sp->n)] = item;   /* Insert the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->items);                          /* Announce available item */
}

int sbuf_remove(sbuf_t *sp) {
    int item;
    P(&sp->items);                          /* Wait for available item */
    P(&sp->mutex);                          /* Lock the buffer */
    item = sp->buf[(++sp->front)%(sp->n)];  /* Remove the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->slots);                          /* Announce available slot */
    return item;
}

void stock_tree_init(stock_tree_t *tree) {
    tree->root = NULL;
    Sem_init(&tree->mutex, 0, 1);
}

int main(int argc, char **argv) {
    Signal(SIGINT, sigint_handler);
    int i, listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    stock_tree_init(&stock_tree);
    load_items(&stock_tree, "stock.txt");

    listenfd = Open_listenfd(argv[1]);

    sbuf_init(&sbuf, SBUFSIZE);
    for (i = 0; i < NTHREADS; i++)
        Pthread_create(&tid, NULL, thread, NULL);

    while (1) {
        clientlen = sizeof(struct sockaddr_storage);
        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);

        char client_hostname[MAXLINE], client_port[MAXLINE];
        Getnameinfo((SA *)&clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        printf("Connected to (%s, %s)\n", client_hostname, client_port);

        sbuf_insert(&sbuf, connfd);
    }
    return 0;
}

void *thread(void *vargp) 
{  
    Pthread_detach(pthread_self()); 
    while (1) { 
        int connfd = sbuf_remove(&sbuf);    /* Remove connfd from buffer */ //line:conc:pre:removeconnfd
        handle_client(connfd);              /* Service client */
	    Close(connfd);
    }
}

item* insert_item(item *node, int id, int left_stock, int price) {
    if (node == NULL) {
        item *new_node = (item *)Malloc(sizeof(item));
        new_node->id = id;
        new_node->left_stock = left_stock;
        new_node->price = price;
        new_node->readcnt = 0;
        Sem_init(&new_node->mutex, 0, 1);
        Sem_init(&new_node->w, 0, 1);
        new_node->left = new_node->right = NULL;
        return new_node;
    }
    if (id < node->id)
        node->left = insert_item(node->left, id, left_stock, price);
    else if (id > node->id)
        node->right = insert_item(node->right, id, left_stock, price);
    return node;
}

item* find_item(item *node, int id) {
    if (node == NULL || node->id == id)
        return node;
    if (id < node->id)
        return find_item(node->left, id);
    else
        return find_item(node->right, id);
}

void load_items(stock_tree_t *tree, const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "Error: Could not open stock file.\n");
        exit(1);
    }

    int id, left_stock, price;
    while (fscanf(fp, "%d %d %d", &id, &left_stock, &price) != EOF) {
        P(&tree->mutex);
        tree->root = insert_item(tree->root, id, left_stock, price);
        V(&tree->mutex);
    }
    fclose(fp);
}

void save_items(item *node, FILE *fp) {
    if (node == NULL) return;
    fprintf(fp, "%d %d %d\n", node->id, node->left_stock, node->price);
    save_items(node->left, fp);
    save_items(node->right, fp);
}

void sigint_handler(int signo) {
    FILE *fp = fopen("stock.txt", "w");
    if (fp != NULL) {
        save_items(stock_tree.root, fp);
        fclose(fp);
    }
    exit(0);
}

void handle_client(int connfd) {
    int n;
    rio_t rio;
    char buf[MAXLINE];
    char command[MAXLINE], id_str[MAXLINE], count_str[MAXLINE];
    int id, count;
    char output[MAXLINE]; // 결과를 저장할 큰 버퍼

    Rio_readinitb(&rio, connfd);

    while ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
        printf("server received %d bytes\n", n);
        
        sscanf(buf, "%s %s %s", command, id_str, count_str);
        buf[n] = '\0';
        output[0] = '\0';
        strcat(output, buf);

        if (strcmp(command, "exit") == 0)
            break;
        else if (strcmp(command, "show") == 0) {
            char stock_info[MAXLINE] = "";
            preorder(stock_tree.root, stock_info);
            strcat(output, stock_info);
        } 
        else if (strcmp(command, "buy") == 0) {
            id = atoi(id_str);
            count = atoi(count_str);
            P(&stock_tree.mutex);
            item *stock = find_item(stock_tree.root, id);
            if (stock) {
                P(&stock->mutex);
                V(&stock_tree.mutex);
                if (stock->left_stock >= count) {
                    stock->left_stock -= count;
                    sprintf(buf, "[buy] success\n");
                }
                else
                    sprintf(buf, "Not enough left stocks\n");
                V(&stock->mutex);
            } 
            else {
                V(&stock_tree.mutex);
            }
            strcat(output, buf);
        } 
        else if (strcmp(command, "sell") == 0) {
            id = atoi(id_str);
            count = atoi(count_str);
            P(&stock_tree.mutex);
            item *stock = find_item(stock_tree.root, id);
            if (stock) {
                P(&stock->mutex);
                V(&stock_tree.mutex);
                stock->left_stock += count;
                sprintf(buf, "[sell] success\n");
                V(&stock->mutex);
            } 
            else {
                V(&stock_tree.mutex);
            }
            strcat(output, buf);
        } 
        else {
            strcat(output, "Invalid command\n");
        }
        Rio_writen(connfd, output, MAXLINE);
    }
}

void preorder(item *node, char *buf) {
    if (node == NULL) return;
    char stock_info[MAXLINE];
    sprintf(stock_info, "%d %d %d\n", node->id, node->left_stock, node->price);
    strcat(buf, stock_info);
    preorder(node->left, buf);
    preorder(node->right, buf);
}